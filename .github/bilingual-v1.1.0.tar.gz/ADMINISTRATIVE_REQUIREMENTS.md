<!-- BILINGUAL_LAYOUT: ENGLISH_LEFT | العربية_يمين -->

<p align="center"><strong>English (left) · العربية (يمين)</strong></p>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h1>Administrative requirements</h1>
<ul>
<li>Organise the repository and files and make the required links available through the course submission policy.</li>
<li>Record sources, changes, seed, package versions, and execution environment.</li>
<li>Complete the README, decision reports, Model Card, and final presentation with evidence from the project.</li>
<li>Prepare a concise five-slide presentation; a PDF exported from a free tool is accepted.</li>
<li>After work is complete, create the final tag, record the exact SHA, build the manifest and package, and retain the private submission receipt.</li>
<li>Keep personal data, grades, and receipts out of public files. Follow the Days 4–5 schedule and resubmission policy announced for the cohort.</li>
</ul>
<p>Assessment is out of 100: 90 technical and administrative points plus 10 presentation points. Pass is 70 and distinction is 95. There is no undisclosed component threshold.</p>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h1>المتطلبات الإدارية / Administrative requirements</h1>
<ul>
<li>تنظيم المستودع والملفات وإتاحة الروابط للمدربة وفق سياسة الدورة.</li>
<li>توثيق المصادر والتغييرات وseed والإصدارات عند التشغيل.</li>
<li>README، تقارير القرارات، Model Card، والعرض النهائي بأدلة المشروع.</li>
<li>العرض خمس شرائح موجزة؛ يقبل PDF من أداة مجانية.</li>
<li>tag وSHA وmanifest والحزمة بعد اكتمال العمل، وإثبات استلام خاص.</li>
<li>لا بيانات شخصية أو درجات في العام. التسليم متاح دون إغلاق آلي؛ اتبع مواعيد اليومين الرابع والخامس وسياسة إعادة التسليم التي تحددها المدربة شفهيًا لدفعتك.</li>
</ul>
<p>Assessment is out of 100: 90 technical/administrative and 10 presentation. Pass 70; distinction 95. No undisclosed pass threshold applies to either component alone.</p>
</td>
</tr>
</table>

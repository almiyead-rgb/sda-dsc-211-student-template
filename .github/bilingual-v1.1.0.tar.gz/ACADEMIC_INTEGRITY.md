<!-- BILINGUAL_LAYOUT: ENGLISH_LEFT | العربية_يمين -->

<p align="center"><strong>English (left) · العربية (يمين)</strong></p>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h1>Academic integrity and privacy</h1>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h1>النزاهة الأكاديمية والخصوصية</h1>
</td>
</tr>
</table>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h2>Permitted practice</h2>
<ul>
<li>Discuss general concepts and help a classmate understand an error message.</li>
<li>Consult course documentation and listed references with proper attribution.</li>
<li>Rerun a lab and change settings in a documented experiment after preserving the baseline.</li>
<li>Request feedback on reasoning, provided that the final results and interpretation remain your work and you can explain them.</li>
</ul>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h2>ما يُسمح به</h2>
<ul>
<li>مناقشة المفاهيم العامة ومساعدة الزملاء في فهم رسالة خطأ.</li>
<li>الرجوع إلى التوثيق والمراجع المدرجة في الدورة مع ذكر المصدر.</li>
<li>إعادة تشغيل اللاب وتعديل الإعدادات في تجربة موثقة بعد حفظ الأساس.</li>
<li>طلب مراجعة منطقك، بشرط أن تبقى النتائج والتفسير النهائيان من عملك وأن تستطيع شرحهما.</li>
</ul>
</td>
</tr>
</table>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h2>Prohibited practice</h2>
<ul>
<li>Submit a classmate's notebook, outputs, or reports as your own.</li>
<li>Copy example or recovery files and present them as live execution.</li>
<li>Manually edit <code>submission.csv</code> to hide a mismatch with the saved model or policy.</li>
<li>Use challenge labels, hidden data, or post-outcome information for training or selection.</li>
<li>Delete or alter execution evidence to hide an error or cross-environment difference.</li>
<li>Publish the private submission channel, receipt, or grade in a public repository.</li>
</ul>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h2>ما لا يُسمح به</h2>
<ul>
<li>تسليم Notebook أو مخرجات أو تقارير من زميل بوصفها عملك.</li>
<li>نسخ ملفات المثال أو Recovery وتقديمها على أنها تشغيل فعلي.</li>
<li>تعديل <code>submission.csv</code> يدويًا لإخفاء اختلاف عن النموذج والسياسة المحفوظين.</li>
<li>إدخال Challenge Labels أو بيانات مخفية أو معلومات ما بعد النتيجة في التدريب أو الاختيار.</li>
<li>حذف أو تعديل أدلة التشغيل لإخفاء خطأ أو اختلاف بين البيئات.</li>
<li>مشاركة قناة التسليم الخاصة أو إيصال الاستلام أو الدرجة في مستودع عام.</li>
</ul>
</td>
</tr>
</table>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h2>Version evidence</h2>
<p>SHA, tag, and manifest establish the exact bytes and version that were checked. They do not prove authorship by themselves. Review therefore includes written reasoning, discussion, and the ability to connect answers to project files.</p>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h2>إثبات النسخة</h2>
<p>يثبت SHA وTag وManifest البايتات والنسخة التي تم فحصها. لا تثبت هذه العناصر وحدها أصالة العمل؛ لذلك تشمل المراجعة التفسير المكتوب والمناقشة وربط الإجابات بملفات المشروع.</p>
</td>
</tr>
</table>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h2>Privacy</h2>
<p>Use a non-personal project identifier. Do not publish a full name, email, phone number, grade, password, token, or credential file. The released course data is synthetic; never add real sensitive data to the project.</p>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h2>الخصوصية</h2>
<p>استخدم معرف مشروع غير شخصي. لا تنشر الاسم الكامل أو البريد أو رقم الهاتف أو الدرجة أو كلمة المرور أو Token أو ملف اعتماد. البيانات المنشورة للدورة اصطناعية؛ لا تضف بيانات حقيقية حساسة إلى المشروع.</p>
</td>
</tr>
</table>

<table role="presentation" width="100%">
<tr>
<td width="50%" valign="top" lang="en" dir="ltr">
<h2>Disclosure of external assistance</h2>
<p>When external assistance contributes to wording or a non-core correction, record it briefly in <code>PROJECT_README.md</code>, stating what you reviewed and implemented yourself. You remain responsible for code, results, interpretation, and the ability to defend the work.</p>
</td>
<td width="50%" valign="top" lang="ar" dir="rtl">
<h2>الإفصاح عن المساعدة الخارجية</h2>
<p>عند الاستفادة من مساعدة خارجية في صياغة أو تصحيح جزء غير جوهري، سجّل ذلك باختصار في <code>PROJECT_README.md</code>، واذكر ما راجعته ونفذته بنفسك. تبقى مسؤولًا عن صحة الشيفرة والنتائج والتفسير وقدرتك على الدفاع عنها.</p>
</td>
</tr>
</table>
